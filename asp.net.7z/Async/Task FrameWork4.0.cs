﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TestTask
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            Stopwatch sw = new Stopwatch();
            sw.Start();

            Task<string> task1 =Task.Factory.StartNew(() => {

                Thread.Sleep(1500);
                return "1";
            });

            Task<string> task2 = Task.Factory.StartNew(() =>
            {
                Thread.Sleep(1500);
                return "2";
            });

            Task.WaitAll(task1,task2);  //阻塞，让两个任务并行走完

            Response.Write(task1.Result + task2.Result);
            sw.Stop();
            Response.Write("<br />");
            Response.Write(sw.Elapsed.TotalSeconds);

            
        }
    }
}