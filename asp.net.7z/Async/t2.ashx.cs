﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Web;

namespace TestAsync
{
    /// <summary>
    /// t2 的摘要说明
    /// </summary>
    public class t2 : HttpTaskAsyncHandler
    {

        public override async Task ProcessRequestAsync(HttpContext context)
        {

            Stopwatch sw = new Stopwatch();
            sw.Start();

            Task<string> tt1 = Task.Run(() =>
            {
                Thread.Sleep(1000);
                return "do1 ok";
            });

            Task<string> tt2 = Task.Run(() =>
            {
                Thread.Sleep(1000);
                return "do2 ok";
            });

            await Task.WhenAll(tt1, tt2); //两个异步方法并行执行，只耗费1秒

            sw.Stop();
            context.Response.Write(tt1.Result + tt2.Result + "over");
            context.Response.Write("<br/>");
            context.Response.Write(sw.Elapsed.TotalSeconds.ToString());

        }

        public override bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}