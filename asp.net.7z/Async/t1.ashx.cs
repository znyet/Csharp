﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using System.Web;

namespace TestAsync
{
    /// <summary>
    /// t1 的摘要说明
    /// </summary>
    public class t1 : HttpTaskAsyncHandler
    {

        public override async Task ProcessRequestAsync(HttpContext context)
        {
            Stopwatch sw = new Stopwatch();
            sw.Start();

            Task<string> tt1 =  do1();
            Task<string> tt2 = do2();

            await Task.WhenAll(tt1, tt2); //两个异步方法并行执行，只耗费1秒

            sw.Stop();
            context.Response.Write(tt1.Result);
            context.Response.Write("<br/>");
            context.Response.Write(tt2.Result);
            context.Response.Write("<br/>");
            context.Response.Write(sw.Elapsed.TotalSeconds.ToString());
        }

        public async Task<string> do1()
        {
            return await Task.Run(() =>
            {
                Thread.Sleep(1000);
                return "do1 ok";
            });
        }

        public async Task<string> do2()
        {
            return await Task.Run(() =>
            {
                Thread.Sleep(1000);
                return "do2 ok";
            });
        }

        public override bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}