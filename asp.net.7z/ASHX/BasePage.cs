﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using XiaoBuPark.Entitys;

namespace BALAGO.Web
{
    public class BasePage : System.Web.UI.Page
    {
        
        protected void Page_PreInit(object sender, EventArgs e)
        {
            if (User == null)
            {
                Response.Redirect("/Account/SignIn.aspx");
                Response.End();
            }
        }

        UserEntity _user;
        protected new UserEntity User
        {
            get 
            {
                if (_user==null)
                {
                    _user = Session["user"] as UserEntity;
                }
                return _user;
            }
        }

    }
}