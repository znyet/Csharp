﻿using System.Web;
using XiaoBuPark.Entitys;

namespace BALAGO.Web.Ashx
{
    /// <summary>
    /// 需要session访问权限
    /// </summary>
    public class BaseFilter:BaseHandler
    {
        public override void ProcessRequest(HttpContext context)
        {
            if (Session["user"] == null)
            {
                Response.Write("session timeOut");
                Response.End();
                return;
            }
            DyMethod();
        }

        #region Method

        UserEntity _user;
        protected UserEntity User
        {
            get
            {
                if (_user == null)
                    _user = Session["user"] as UserEntity;
                return _user;
            }
        }


        #endregion
    }
}