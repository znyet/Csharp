﻿using System;
using System.Web;

using Newtonsoft.Json;
using System.Web.SessionState;
using System.Reflection;
using Newtonsoft.Json.Converters;

namespace BALAGO.Web.Ashx
{
    public class BaseHandler : IHttpHandler, IRequiresSessionState
    {
        public virtual void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/plain";
            DyMethod();
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }

        #region Method

        //获取当前的HttpRequest
        protected HttpRequest Request
        {
            get
            {
                return HttpContext.Current.Request;
            }
        }

        //获取当前的HttpResponse
        protected HttpResponse Response
        {
            get
            {
                return HttpContext.Current.Response;
            }
        }

        //获取当前的HttpSessionState
        protected HttpSessionState Session
        {
            get
            {
                return HttpContext.Current.Session;
            }
        }

        //返回数据
        protected void ReturnData(object data)
        {
            Response.Write(data);
        }

        //返回序列化json
        protected void ReturnJson(object data, string format = "yyyy-MM-dd HH:mm:ss")
        {
            if (string.IsNullOrEmpty(format))
            {
                Response.Write(JsonConvert.SerializeObject(data));
            }
            else
            {
                IsoDateTimeConverter iso = new IsoDateTimeConverter();
                iso.DateTimeFormat = format;
                Response.Write(JsonConvert.SerializeObject(data, iso));
            }
        }

        protected void DyMethod()
        {
            string a = Request.QueryString["a"];
            if (!string.IsNullOrEmpty(a))
            {
                MethodInfo methodInfo = this.GetType().GetMethod(a, BindingFlags.Instance | BindingFlags.Public | BindingFlags.IgnoreCase);
                if (methodInfo != null)
                {
                    //调用方法
                    methodInfo.Invoke(this, null);
                }
                else
                {
                    throw new ApplicationException(string.Format("没有找到方法{0}", a));
                }
            }
            else
            {
                throw new ArgumentNullException("请提供a参数");
            }
        }

        #endregion
    }
}