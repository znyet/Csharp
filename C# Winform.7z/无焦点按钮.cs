﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Windows.Forms;

namespace ClientForm.AppCode
{
    public class Utils
    {
        public static bool StartProcess(string runFilePath, params string[] args)
        {
            if (!File.Exists(runFilePath))
            {
                return false;
            }

            string s = "";
            foreach (string arg in args)
            {
                s = s + arg + " ";
            }
            s = s.Trim();
            Process process = new Process();//创建进程对象    
            ProcessStartInfo startInfo = new ProcessStartInfo(runFilePath, s); // 括号里是(程序名,参数)
            process.StartInfo = startInfo;
            process.Start();
            return true;
        }

        public static void SetButtonNoFocus(Button button)  
        {  
            MethodInfo methodinfo = button.GetType().GetMethod("SetStyle",BindingFlags.NonPublic 
                | BindingFlags.Instance | BindingFlags.InvokeMethod);  
            methodinfo.Invoke(button,BindingFlags.NonPublic 
                | BindingFlags.Instance | BindingFlags.InvokeMethod,null,new object[] 
                {ControlStyles.Selectable,false},Application.CurrentCulture);  
        }

    }
}
