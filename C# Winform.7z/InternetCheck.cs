﻿using System;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Threading;

namespace Common.Utils
{
    public class InternetCheck
    {
        //ping ip
        public static bool Ping(string ip, int timeout = 200)
        {
            try
            {
                using (Ping ping = new Ping())
                {
                    PingReply reply = ping.Send(ip, timeout);
                    if (reply.Status == IPStatus.Success)
                        return true;
                    else
                        return false;
                }
                
            }
            catch
            {
                return false;
            }
        }

        public static PingModel PingModel(string ip, int timeout = 200)
        {
            PingModel model = new PingModel();
            model.Ip = ip;
            try
            {
                using (Ping ping = new Ping())
                {
                    PingReply reply = ping.Send(ip, timeout);
                    if (reply.Status == IPStatus.Success)
                    {
                        model.Ok = true;
                        model.MiniSecond = reply.RoundtripTime;
                    }
                    else
                        model.Ok = false;
                }
            }
            catch
            {
                model.Ok = false;
            }
            return model;

        }

        //判断局域网状态
        [DllImport("wininet")]
        private extern static bool InternetGetConnectedState(out int conState, int reder);
        public static bool LanStatus()
        {
            int conStatus = 0;
            return InternetGetConnectedState(out conStatus, 0);
        }

        //扫描id和端口号 tcp
        public static bool TcpCheck(string host, int port = 80, int timeout = 200)
        {
            using (TcpClient tcp = new TcpClient())
            {
                tcp.SendTimeout = tcp.ReceiveTimeout = timeout;
                try
                {
                    IAsyncResult oAsyncResult = tcp.BeginConnect(host, port, null, null);
                    oAsyncResult.AsyncWaitHandle.WaitOne(timeout, true);//1000为超时时间 
                    if (tcp.Connected)
                        return true;
                    else
                        return false;
                }
                catch
                {
                    return false;
                }
            }
        }

    }

    public class PingModel
    {
        public string Ip { get; set; }
        public bool Ok { get; set; }
        public long MiniSecond { get; set; } //答复毫秒数目
    }




}
