﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestDelegate
{
    //Action 没返回值 支持16个参数
    class ActionClass
    {
        public event Action<string,int> OnClick;

        public void Do()
        {
            if (OnClick != null)
            {
                OnClick("这是Action编写的事件",1);
            }
        }

        //清除所有事件方法一
        public void ClearOnClick()
        {
            while (OnClick != null)
            {
                OnClick -= OnClick;
            }
        }
    }
}
