﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestDelegate
{
    public delegate void MyDelegate(string name);

    //通用委托
    public class DelegateClass
    {
        public event MyDelegate OnClick;

        public void Do()
        {
            if (OnClick != null)
            {
                OnClick("这是Deletegate编写的事件");
            }
        }
    }
}
