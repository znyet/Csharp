﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestDelegate
{
    public delegate void MyDelegate(string name);

    //通用委托
    public class DelegateClass
    {
        public event MyDelegate OnClick;

        public void Do()
        {
            if (OnClick != null)
            {
                OnClick("这是Deletegate编写的事件");
            }
        }

        //清除所有事件方法一
        public void ClearOnClick()
        {
            while (OnClick != null)
            {
                OnClick -= OnClick;
            }        
        }

    }
}
