﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestDelegate
{
    class FuncClass
    {
        public event Func<string, int> OnClick;

        public void Do()
        {
            if (OnClick != null)
            {
                int result = OnClick("这是Func编写的事件");
                Console.WriteLine("这是由调用者返回来的值:" + result);
            }
        }

        //清除所有事件方法一
        public void ClearOnClick()
        {
            while (OnClick != null)
            {
                OnClick -= OnClick;
            }
        }
    }
}
