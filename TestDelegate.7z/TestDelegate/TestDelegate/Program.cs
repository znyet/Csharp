﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace TestDelegate
{
    class Program
    {
        static void Main(string[] args)
        {
            var deClass = new DelegateClass();
            deClass.OnClick += name =>
            {
                Console.WriteLine(name);
            };
            deClass.Do();


            var acClass = new ActionClass();
            acClass.OnClick += (a, b) =>
            {
                Console.WriteLine(a + b);
            };
            acClass.Do();

            var fuClass = new FuncClass();
            fuClass.OnClick += name =>
            {
                Console.WriteLine(name);
                return 1;
            };
            fuClass.Do();


            /************清除所有事件方法2*****************/
            ClearAllEvents(deClass, "OnClick");
            ClearAllEvents(acClass, "OnClick");
            ClearAllEvents(fuClass, "OnClick");


            Console.ReadKey();

        }



        #region 清除事件

        public static void ClearAllEvents(object objectHasEvents, string eventName)
        {
            if (objectHasEvents == null)
            {
                return;
            }
            try
            {
                EventInfo[] events = objectHasEvents.GetType().GetEvents(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
                if (events == null || events.Length < 1)
                {
                    return;
                }
                for (int i = 0; i < events.Length; i++)
                {
                    EventInfo ei = events[i];
                    if (ei.Name == eventName)
                    {
                        FieldInfo fi = ei.DeclaringType.GetField(eventName, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
                        if (fi != null)
                        {
                            fi.SetValue(objectHasEvents, null);
                        }
                        break;
                    }
                }
            }
            catch
            {
            }
        }

        #endregion

    }
}
