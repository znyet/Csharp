﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestDelegate
{
    class Program
    {
        static void Main(string[] args)
        {
            var deClass = new DelegateClass();
            deClass.OnClick += name =>
            {
                Console.WriteLine(name);
            };
            deClass.Do();


            var acClass = new ActionClass();
            acClass.OnClick += (a, b) =>
            {
                Console.WriteLine(a + b);
            };
            acClass.Do();

            var fuClass = new FuncClass();
            fuClass.OnClick += name =>
            {
                Console.WriteLine(name);
                return 1;
            };
            fuClass.Do();

            Console.ReadKey();

        }

    }
}
